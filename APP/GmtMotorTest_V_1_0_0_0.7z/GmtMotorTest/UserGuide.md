# GMT Motor Test Kit User Manual

___
## Working/Test Folder


___

## ***Rolling Test***

___

### **Menu and Tool Bar**

![toolbar](Assets/toolbar.png)
![Test Folder](Assets/test_folder.png)

```c
- APP初次啟動時會在使用者桌面建立一個名為`MotorTest`的Working Folder(可以在File Menu中修改)
- 每次測試時都會在Working Folder中建立一個Test Folder如 `rolling_mmdd_hhmmss`(會用目前的日期時間為流水號為Test Folder命名)
- 所有測試結果都會存放於此Test Folder
```


![menu](Assets/menu.png)

___

### **PWM Control Panel**

:bulb: %{color:red}輸入後須按Tab才會修改修改%

![pwm panel](Assets/pwm_panel.png)

___

### **Power Supply Control Panel**

:bulb: %{color:red}輸入後須按Tab才會修改修改%

![power panel](Assets/power_panel.png)

```c
* VM	: 電壓
* ISet	: 電流
* OVP	: 過壓保護
* OCP	: 過流保護
 ```
___

### **主要參數**

:bulb: %{color:red}輸入後須按Tab才會修改修改%

![pole pair](Assets/polepair.png)

![misc](Assets/misc.png)

![datagrid](Assets/datagrid.png)

:point_right: 選取列後按Delete可刪除

```c
* Insert	: 在選取列下方加入資料
* Add		: 在最下方加入資料
* Repeat	: 重複Rolling List的測試設定
```
___

### **RPM Information: RPM圖上的統計值**

![RPM Information](Assets/rpminformation.png)

___

### **測試按鈕**

![test button](Assets/testbutton.png)

___
### Rolling Plot View

![Rolling Plot View](Assets/rolling_plot_view.png)

```c
1 : 顯示或隱藏轉速/電流曲線
2 : 顯示/隱藏 Cursor
3 : 顯示/隱藏 圖例
4 : 在測試時可選擇要不要即時更新 Rolling Plot
5 : 按 F1 可儲存目前Cursor座標於C1
5 : 按 F2 可儲存目前Cursor座標於C2
6 : 計算 C1,C2 差值
```

### 右鍵選單

![Plot Right Click](Assets/plot_right_click.png)

### 快速鍵

![Rpm Hotkey](Assets/rpm_hotkey.png)



